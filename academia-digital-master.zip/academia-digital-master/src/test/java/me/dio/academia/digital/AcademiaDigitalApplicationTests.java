package me.dio.academia.digital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademiaDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
